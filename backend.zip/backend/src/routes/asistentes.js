const express = require('express');
const router = express.Router();

module.exports = (db) => {
    // Obtener todos los asistentes
    router.get('/', (req, res) => {
        db.query('SELECT * FROM asistentes', (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        });
    });

    // Obtener un asistente específico por ID
    router.get('/:id', (req, res) => {
        const { id } = req.params;
        db.query('SELECT * FROM asistentes WHERE id = ?', [id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.length === 0) return res.status(404).json({ message: 'Asistente no encontrado' });
            res.json(results[0]);
        });
    });

    // Crear un nuevo asistente
    router.post('/:name', (req, res) => {
        const name = req.params.name;
        db.query('INSERT INTO asistentes (name) VALUES (?)', [name], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.status(201).json({ id: results.insertId, name });
        });
    });

    // Actualizar un asistente
    router.put('/:id/:name', (req, res) => {
        const { id, name } = req.params;
        db.query('UPDATE asistentes SET name = ? WHERE id = ?', [name, id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.affectedRows === 0) {
                return res.status(404).json({ message: 'Asistente no encontrado' });
            }
            res.json({ id, name });
        });
    });

    // Eliminar un asistente
    router.delete('/:id', (req, res) => {
        const { id } = req.params;
        db.query('DELETE FROM asistentes WHERE id = ?', [id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.affectedRows === 0) {
                return res.status(404).json({ message: 'Asistente no encontrado' });
            }
            res.status(200).json({ message: `Asistente con ID ${id} eliminado satisfactoriamente` });
        });
    });

    return router;
};
