const express = require('express');
const router = express.Router();

module.exports = (db) => {
    // Obtener todos los eventos
    router.get('/', (req, res) => {
        db.query('SELECT * FROM eventos', (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        });
    });

   /* router.get('/desc', (req, res) => {
        db.query('SELECT * FROM eventos ORDER BY id DESC', (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        });
    });*/

    // Obtener un evento específico por ID
    router.get('/:id', (req, res) => {
        const { id } = req.params;
        db.query('SELECT * FROM eventos WHERE id = ?', [id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.length === 0) return res.status(404).json({ message: 'Evento no encontrado' });
            res.json(results[0]);
        });
    });

    // Crear un nuevo evento
    router.post('/:name', (req, res) => {
        const name = req.params.name;
        db.query('INSERT INTO eventos (name) VALUES (?)', [name], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.status(201).json({ id: results.insertId, name });
        });
    });

    // Actualizar un evento
    router.put('/:id/:name', (req, res) => {
        const { id, name } = req.params;
        db.query('UPDATE eventos SET name = ? WHERE id = ?', [name, id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.affectedRows === 0) {
                return res.status(404).json({ message: 'Evento no encontrado' });
            }
            res.json({ id, name });
        });
    });

    // Eliminar un evento
    router.delete('/:id', (req, res) => {
        const { id } = req.params;
        db.query('DELETE FROM eventos WHERE id = ?', [id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.affectedRows === 0) {
                return res.status(404).json({ message: 'Evento no encontrado' });
            }
            res.status(200).json({ message: `Evento con ID ${id} eliminado satisfactoriamente` });
        });
    });

    return router;
};
