const express = require('express');
const router = express.Router();

module.exports = (db) => {
    // Marcar asistencia con parámetros en la URL
    router.post('/:evento_id/:asistente_id', (req, res) => {
        const { evento_id, asistente_id } = req.params; // Obtener los parámetros de la URL
        db.query('INSERT INTO asistencia (evento_id, asistente_id) VALUES (?, ?)', 
            [evento_id, asistente_id], (err, results) => {
                if (err) return res.status(500).json({ error: err });
                res.status(201).json({ id: results.insertId, evento_id, asistente_id });
            });
    });

     // Obtener asistencias generales
     router.get('/eventos', (req, res) => {
        db.query('SELECT * FROM asistencia',(err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        });
    });

    // Eliminar asistencia por id
    router.delete('/:evento_id/:asistente_id', (req, res) => {
        const { evento_id, asistente_id } = req.params; // Obtener los parámetros de la URL
        const query = `
            DELETE FROM asistencia 
            WHERE evento_id = ? AND asistente_id = ?;
        `;
        
        db.query(query, [evento_id, asistente_id], (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        });
    });

    // Obtener asistencia de un evento específico con los nombres de evento y asistente
    router.get('/eventos/:evento_id', (req, res) => {
        const { evento_id } = req.params;

        const query = `
        SELECT 
            MIN(asistencia.id) AS asistencia_id, -- Obtiene el ID más bajo (puedes usar cualquier función de agregación)
            asistentes.name AS asistente_name,
            eventos.name AS evento_name
        FROM 
            asistencia
        JOIN 
            asistentes ON asistencia.asistente_id = asistentes.id
        JOIN 
            eventos ON asistencia.evento_id = eventos.id
        WHERE 
            asistencia.evento_id = ?
        GROUP BY 
            asistentes.id, asistentes.name, eventos.name

    `;
        db.query(query, [evento_id], (err, results) => {
            if (err) {
                return res.status(500).json({ error: err });
            }
            res.json(results);
        });
    });

    return router;
};
