const express = require('express');
const mysql = require('mysql2');
const eventosRoutes = require('./routes/eventos');
const asistentesRoutes = require('./routes/asistentes');
const asistenciaRoutes = require('./routes/asistencia');

const app = express();
const PORT = 3000;

// Middleware para analizar JSON
app.use(express.json());

// Conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',      // Cambia si tu DB está en otro host
    user: 'root',           // Tu usuario de MySQL
    password: '1234',       // Tu contraseña de MySQL
    database: 'asistencias' // Nombre de tu base de datos
});

// Conectar a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL.');
});

// Rutas
app.use('/eventos', eventosRoutes(db));
app.use('/asistentes', asistentesRoutes(db));
app.use('/asistencia', asistenciaRoutes(db));

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
